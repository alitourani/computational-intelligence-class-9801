import pafy
from tkinter import *
import cv2 as openCV
import imutils
import time
import numpy as np

#definition of capture object
capture = openCV.VideoCapture(0)

# Create 3 separate lists for storing Model_Mean_Values, Age and Gender.
MODEL_MEAN_VALUES = (78.4263377603, 87.7689143744, 114.895847746)
genderList = ['Male', 'Female']
gender_list2 = ['Female', 'Female']
ageList = ['(0, 4)', '(4, 8)', '(8, 15)', '(15, 21)', '(21, 24)',
        '(25, 32)', '(38, 43)', '(48, 53)', '(60, 100)']


#set the video type using the default camera
def videoType(a):
	if a == 0:
		capture = openCV.VideoCapture(0)
		capture.set(3, 480)  # set width
		capture.set(4, 640)  # set height


#Convert the image to gray image as OpenCV face detector expects gray images.
def imageToGray(image):
	return openCV.cvtColor(image, openCV.COLOR_BGR2GRAY)

#Load the pre-built model for facial detection.
def loadPreBuiltFacialDet():
	return openCV.CascadeClassifier('data/haarcascade_frontalface_alt.xml')

#Function to detect objects
def faceDetect(f_cascade ,image, scaleFactor, minNeighbors):
	return f_cascade.detectMultiScale(image, scaleFactor, minNeighbors)

# get faces: Loop through the list of faces and draw rectangles on the human faces in the video.
def getFaces(faces, image, font):
	for (x, y, w, h)in faces:
		openCV.rectangle(image, (x, y), (x+w, y+h), (255, 255, 0), 2)

		# Get Face
		faceImage = image[y:y+h, h:h+w].copy()
		blob = openCV.dnn.blobFromImage(faceImage, 1, (227, 227), MODEL_MEAN_VALUES, swapRB=False)

		#Predict Gender
		genderNet.setInput(blob)
		genderPredicion = genderNet.forward()
		gender = genderList[genderPredicion[0].argmax()]
		print("Gender : " + gender)

		#Predict Age
		ageNet.setInput(blob)
		agePredictions = ageNet.forward()
		age = ageList[agePredictions[0].argmax()]
		print("Age Range: " + age)

		overlay_text = "%s %s" % (gender, age)
		openCV.putText(image, overlay_text, (x, y), font, 1, (255, 255, 255), 2, openCV.LINE_AA)

	openCV.imshow('frame', image)
	



def caffeModelInitialize():
	
	ageNet = openCV.dnn.readNetFromCaffe(
		'data/deploy_age.prototxt', 
		'data/age_net.caffemodel')

	genderNet = openCV.dnn.readNetFromCaffe(
		'data/deploy_gender.prototxt', 
		'data/gender_net.caffemodel')

	return(ageNet, genderNet)

def read_from_camera(ageNet, genderNet):
	font = openCV.FONT_HERSHEY_SIMPLEX

	while True:
		#check wheather the capture read was true or false
		ret, image = capture.read()

		#Load the pre-built model for facial detection.
		f_cascade = loadPreBuiltFacialDet()
		
		#Convert the image to gray image as OpenCV face detector expects gray images.
		gray = imageToGray(image)

		#Function to detect objects(faces)
		faces = faceDetect(f_cascade, gray, 1.1, 5)

		if(len(faces) > 0):
			print("Found {} faces".format(str(len(faces))))

		getFaces(faces, image, font)

		#0xFF is a hexadecimal constant which is 11111111 in binary.
		if openCV.waitKey(1) & 0xFF == ord('q'):
			break
		

detectionBoolean = False
ageNet, genderNet = caffeModelInitialize()

def create_window():
	detectionBoolean = True

	if detectionBoolean == True:
		
		read_from_camera(ageNet, genderNet)

if __name__ == "__main__":
	#set the video type using the default camera
	videoType(0)

	root = Tk()
	menu = Menu(root)
	root.config(menu=menu)
	filemenu = Menu(menu)
	menu.add_cascade(label='File', menu=filemenu)
	filemenu.add_command(label='New')
	filemenu.add_command(label='Open...')
	filemenu.add_separator()
	filemenu.add_command(label='Exit', command=root.quit)
	helpmenu = Menu(menu)
	menu.add_cascade(label='Help', menu=helpmenu)
	helpmenu.add_command(label='About')

	root.title('Age & Gender Detection')
	button1 = Button(root, text='Start Detection', width=25, command=create_window)
	button1.pack()

	button2 = Button(root, text="Close", width=25, command=root.destroy)
	button2.pack()

	mainloop()

	




